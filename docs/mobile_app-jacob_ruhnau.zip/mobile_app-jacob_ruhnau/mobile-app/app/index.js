import { Redirect } from 'expo-router';

export default function App() {
    return <Redirect href={"/(drawer)/manage"}/>;
}