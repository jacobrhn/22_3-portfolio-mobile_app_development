import { Stack } from "expo-router";

export default function homeLayout() {
  return <Stack screenOptions={{ headerShown: false }}></Stack>;
}