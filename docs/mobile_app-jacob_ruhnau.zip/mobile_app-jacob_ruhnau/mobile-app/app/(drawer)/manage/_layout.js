import { Stack } from "expo-router";

export default function settingsLayout() {
  return <Stack screenOptions={{ headerShown: false }}></Stack>;
}